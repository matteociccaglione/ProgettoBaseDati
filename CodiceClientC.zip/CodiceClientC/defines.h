#pragma once

#include <stdbool.h>
#include <mysql.h>

struct configuration {
	char* host;
	char* db_username;
	char* db_password;
	unsigned int port;
	char* database;

	char username[128];
	char password[128];
};

extern struct configuration conf;
typedef struct __list_film {
	char title[61];
	char regista[46];
	int settore;
	int copie;
	char posizione[46];
	struct __list_film* next;
}list_film;
typedef struct __noleggi {
	char cliente[46];
	char title[61];
	char regista[46];
	char data[12];
	int settore;
	struct __noleggi* next;
}noleggi;
extern int areYouSure();
extern list_film* dump_result_set_film(MYSQL* conn, MYSQL_STMT* stmt, char* title);
extern int parse_config(char* path, struct configuration* conf);
extern int getInput(int lung, char* stringa, bool hide);
extern int yesOrNo(char* question);
extern char multiChoice(char* domanda, char choices[], int num);
extern void print_error(MYSQL* conn, char* message);
extern void print_stmt_error(MYSQL_STMT* stmt, char* message);
extern void finish_with_error(MYSQL* conn, char* message);
extern void finish_with_stmt_error(MYSQL* conn, MYSQL_STMT* stmt, char* message, bool close_stmt);
extern bool setup_prepared_stmt(MYSQL_STMT** stmt, char* statement, MYSQL* conn);
extern void dump_result_set(MYSQL* conn, MYSQL_STMT* stmt, char* title);
extern void run_as_employer(MYSQL* conn, char* username);
extern void run_as_manager(MYSQL* conn, int isAdmin);
extern void run_as_administrator(MYSQL* conn);
extern int inserisciOrario(char* question, char* string, int length);
extern void leggiNumeri(int length, char* string);
extern int dump_result_set_with_list(MYSQL* conn, MYSQL_STMT* stmt, char* title, char** list, int maxRow);
extern void dump_multiple_rs(MYSQL* conn, MYSQL_STMT* stmt, char* title, HANDLE handle);
extern int contains(char* string, char character);