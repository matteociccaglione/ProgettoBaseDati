#include"defines.h"
#include<stdio.h>
#include<stdlib.h>
char myUsername[46];
#define MAX_EMAIL_CLIENTE 200;
#define MAX_TELEFONO_CLIENTE 100;
void update_copy(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[5];
	MYSQL_BIND param1[1];
	MYSQL_STMT* preparedStmt2;
	MYSQL_TIME* date = (MYSQL_TIME*)malloc(sizeof(MYSQL_TIME));
	list_film* head = NULL;
	list_film* temp;
	if (date == NULL) {
		printf("Errore malloc\n");
		exit(0);
	}
	memset(date, 0, sizeof(date));
	int numOF = 0;
	char title[61];
	char regista[46];
	int settore;
	char numero[46];
	char settoreI[20];
	int copyN;
	char copy[10];
	int i = 0;
	if (!setup_prepared_stmt(&preparedStmt2, "call visualizzaFilmCentro(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to procede\n", false);
	}
	memset(param1, 0, sizeof(param1));
	param1[0].buffer = myUsername;
	param1[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param1[0].buffer_length = strlen(myUsername);
	if (mysql_stmt_bind_param(preparedStmt2, param1) != 0) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to procede\n", true);
	}
	if (mysql_stmt_execute(preparedStmt2) != 0) {
		print_stmt_error(preparedStmt2, "Unable to show film list\n");
		return;
	}
	else {
		head = dump_result_set_film(conn, preparedStmt2, "Film catalog\n");
		temp = head;
		while (temp != NULL) {
			numOF++;
			temp = temp->next;
		}
	}
	if (numOF == 0) {
		printf("There are no films\n");
		return;
	}
	do {
		printf("Enter the number of the movie you want to order\n");
		leggiNumeri(45, numero);
	} while (atoi(numero) >= numOF);
	temp = head;
	i = 0;
	while (i < atoi(numero)) {
		temp = temp->next;
		i++;
	}
	strcpy(title, temp->title);
	strcpy(regista, temp->regista);
	settore = temp->settore;
	mysql_stmt_close(preparedStmt2);
	free_list_film(head);
	printf("Enter the number of copies to order\n");
	leggiNumeri(9, copy);
	copyN = atoi(copy);
	memset(param, 0, sizeof(param));
	param[0].buffer = myUsername;
	param[0].buffer_length = strlen(myUsername);
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = title;
	param[1].buffer_length = strlen(title);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = regista;
	param[2].buffer_length = strlen(regista);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = &settore;
	param[3].buffer_length = sizeof(settore);
	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[4].buffer = &copyN;
	param[4].buffer_length = sizeof(copyN);
	param[4].buffer_type = MYSQL_TYPE_LONG;
	if (!setup_prepared_stmt(&preparedStmt, "call aggiornaDisponibilita(?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize request statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to order film\n");
		}
		else {
			printf("Properly order movie\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void remove_client(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[1];
	char code[46];
	printf("Enter the customer's tax code\n");
	getInput(45, code, false);
	memset(param, 0, sizeof(param));
	param[0].buffer = code;
	param[0].buffer_length = strlen(code);
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	if (!setup_prepared_stmt(&preparedStmt, "call rimuoviCliente(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to set the statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Cannot set parameters\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to remove");
		}
		else {
			printf("Customer removed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void handle_client(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[2];
	char result[61];
	char fiscal_code[46];
	char store_procedure[1024];
	char opt[4] = { '1','2','3','4' };
	char scelta = multiChoice("Choose: 1)Enter new telephone number\n,2) Enter new email\n,3)Enter new address\n4) Exit", opt, 4);
	switch (scelta) {
	case'1':
		strcpy(store_procedure, "call inserisciTelefonoCliente(?,?)");
		printf("Enter the telephone number\n");
		leggiNumeri(10, result);
		break;
	case '2':
		strcpy(store_procedure, "call inserisciEmailCliente(?,?)");
		printf("Enter the email\n");
		getInput(45, result, false);
		break;
	case '3':
		strcpy(store_procedure, "call inserisciIndirizzoCliente(?,?)");
		printf("Enter the address\n");
		getInput(60, result, false);
		break;
	case '4':
		return;
	}
	printf("Enter the customer's tax code\n");
	getInput(45, fiscal_code, false);
	memset(param, 0, sizeof(param));
	param[1].buffer = fiscal_code;
	param[1].buffer_length = strlen(fiscal_code);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = result;
	param[0].buffer_length = strlen(result);
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	if (!setup_prepared_stmt(&preparedStmt, store_procedure, conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Failed to initialize statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Cannot set parameters\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to insert");
		}
		else {
			printf("Update completed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
int containsChar(char* string, char character) {
	int c = 0;
	while (string[c] != '\0') {
		if (string[c] == character) {
			return 1;
		}
		c++;
	}
	return 0;
}
void cercaCliente(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[1];
	char cf[46];
	printf("Enter the customer's tax code\n");
	getInput(45, cf, false);
	memset(param, 0, sizeof(param));
	param[0].buffer = cf;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(cf);
	if (!setup_prepared_stmt(&preparedStmt, "call trovaCliente(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to procede\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param ", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, "Unable to found client");
		}
		else {
			printf("CLIENTE: %s\n", cf);
			dump_multiple_rs(conn, preparedStmt, "Customer data",GetStdHandle(STD_OUTPUT_HANDLE));
			mysql_stmt_next_result(preparedStmt);
			dump_multiple_rs(conn, preparedStmt, "Telephone numbers:",GetStdHandle(STD_OUTPUT_HANDLE));
			mysql_stmt_next_result(preparedStmt);
			dump_multiple_rs(conn, preparedStmt, "Email:",GetStdHandle(STD_OUTPUT_HANDLE));
			mysql_stmt_next_result(preparedStmt);
			dump_multiple_rs(conn, preparedStmt, "Address:", GetStdHandle(STD_OUTPUT_HANDLE));
			mysql_stmt_next_result(preparedStmt);
			dump_result_set(conn, preparedStmt, "Rentals in progress:");
		}
	}
	mysql_stmt_close(preparedStmt);
}

void rimuoviFilmSettore(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_STMT* preparedStmt2;
	MYSQL_BIND param1[1];
	list_film* head = NULL;
	list_film* temp;
	int numOF = 0;
	int i = 0;
	char numero[46];
	MYSQL_BIND param[4];
	char titolo[61];
	char regista[46];
	char settoreC[10];
	int settore;
	if (!setup_prepared_stmt(&preparedStmt2, "call visualizzaFilmCentro(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to procede\n", false);
	}
	memset(param1, 0, sizeof(param1));
	param1[0].buffer = myUsername;
	param1[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param1[0].buffer_length = strlen(myUsername);
	if (mysql_stmt_bind_param(preparedStmt2, param1) != 0) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to procede\n", true);
	}
	if (mysql_stmt_execute(preparedStmt2) != 0) {
		print_stmt_error(preparedStmt2, "Unable to show film list\n");
		return;
	}
	else {
		head = dump_result_set_film(conn, preparedStmt2, "Catalogo film\n");
		temp = head;
		while (temp != NULL) {
			numOF++;
			temp = temp->next;
		}
	}
	if (numOF == 0) {
		printf("There are no films\n");
		return;
	}
	do {
		printf("Enter the number of the movie you want to remove\n");
		leggiNumeri(45, numero);
	} while (atoi(numero) >= numOF);
	temp = head;
	i = 0;
	while (i < atoi(numero)) {
		temp = temp->next;
		i++;
	}
	strcpy(titolo, temp->title);
	strcpy(regista, temp->regista);
	settore = temp->settore;
	free_list_film(head);
	mysql_stmt_close(preparedStmt2);
	memset(param, 0, sizeof(param));
	param[0].buffer = titolo;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(titolo);
	param[1].buffer = regista;
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer_length = strlen(regista);
	param[2].buffer = &settore;
	param[2].buffer_type = MYSQL_TYPE_LONG;
	param[2].buffer_length = sizeof(settore);
	param[3].buffer = myUsername;
	param[3].buffer_length = strlen(myUsername);
	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	if (!setup_prepared_stmt(&preparedStmt, "call rimuoviFilmSettore(?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to procede\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param ", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, "Unable to remove film");
		}
		else {
			printf("Film successfully removed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void visualizzaTitoliScaduti(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	if (!setup_prepared_stmt(&preparedStmt, "call stampaFilmScaduti()",conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to procede\n", false);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, " Unable to load list of film\n");
	}
	else {
		dump_result_set(conn, preparedStmt, "Expired rentals\n");
	}
	mysql_stmt_close(preparedStmt);
}
void restituisciFilm(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	noleggi* head = NULL;
	noleggi* temp;
	int numOF = 0;
	char numero[46];
	MYSQL_BIND param[5];
	char title[61];
	char regista[46];
	int settore;
	char settoreI[20];
	char cliente[46];
	MYSQL_BIND par1[1];
	memset(par1, 0, sizeof(par1));
	par1[0].buffer = myUsername;
	par1[0].buffer_length = strlen(myUsername);
	par1[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	if (!setup_prepared_stmt(&preparedStmt, "call visualizzaNoleggi(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to procede\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, par1) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param\n", true);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, " Unable to return film\n");
	}
	else {
		head=dump_noleggi(conn, preparedStmt, "Rentals in progress\n");
		if (head == NULL) {
			printf("There are no rentals in progress\n");
			return;
		}
		temp = head;
		while (temp != NULL) {
			numOF++;
			temp = temp->next;
		}
	}
	mysql_stmt_close(preparedStmt);
	if (numOF == 0) {
		printf("There are no films\n");
		return;
	}
	do {
		printf("Enter the number of the rental to be canceled\n");
		leggiNumeri(45, numero);
	} while (atoi(numero) > numOF);
	numOF = 0;
	temp = head;
	while (numOF < atoi(numero)) {
		temp = temp->next;
	}
	strcpy(cliente, temp->cliente);
	strcpy(title, temp->title);
	strcpy(regista, temp->regista);
	settore = temp->settore;
	free_list_noleggi(head);
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = cliente;
	param[0].buffer_length = strlen(cliente);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = title;
	param[1].buffer_length = strlen(title);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = regista;
	param[2].buffer_length = strlen(regista);
	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = myUsername;
	param[4].buffer_length = strlen(myUsername);
	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &settore;
	param[3].buffer_length = sizeof(settore);
	if (!setup_prepared_stmt(&preparedStmt, "call restituisciFilm(?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to procede\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to return film\n");
		}
		else {
			printf("Movie returned successfully\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void noleggiaFilm(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[6];
	MYSQL_BIND param1[1];
	MYSQL_STMT* preparedStmt2;
	MYSQL_TIME* date = (MYSQL_TIME*)malloc(sizeof(MYSQL_TIME));
	list_film* head = NULL;
	list_film* temp;
	if (date == NULL) {
		printf("Errore malloc\n");
		exit(0);
	}
	memset(date, 0, sizeof(date));
	int numOF = 0;
	char title[61];
	char regista[46];
	char cliente[46];
	int settore;
	char numero[46];
	char settoreI[20];
	char day[3];
	char month[3];
	char year[5];
	int i = 0;
	if (!setup_prepared_stmt(&preparedStmt2, "call visualizzaFilmCentro(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to procede\n", false);
	}
	memset(param1, 0, sizeof(param1));
	param1[0].buffer = myUsername;
	param1[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param1[0].buffer_length = strlen(myUsername);
	if (mysql_stmt_bind_param(preparedStmt2, param1) != 0) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to procede\n", true);
	}
	if (mysql_stmt_execute(preparedStmt2) != 0) {
		print_stmt_error(preparedStmt2, "Unable to show film list\n");
		return;
	}
	else {
		head=dump_result_set_film(conn, preparedStmt2, "Film catalog\n");
		temp = head;
		while (temp != NULL) {
			numOF++;
			temp = temp->next;
		}
	}
	if (numOF == 0) {
		printf("There are no films\n");
		return;
	}
	do {
		printf("Enter the number of the movie you want to rent\n");
		leggiNumeri(45, numero);
	} while (atoi(numero) >= numOF);
	temp = head;
	i = 0;
	while (i < atoi(numero)) {
		temp = temp->next;
		i++;
	}
	strcpy(title, temp->title);
	strcpy(regista, temp->regista);
	settore = temp->settore;
	mysql_stmt_close(preparedStmt2);
	free_list_film(head);
	printf("Enter the customer\n");
	getInput(45, cliente, false);
	printf("Enter the expiration date\n");
	printf("Enter the day\n");
	leggiNumeri(2, day);
	printf("Enter the month\n");
	leggiNumeri(2, month);
	printf("Enter the year\n");
	leggiNumeri(4, year);
	if (!setup_prepared_stmt(&preparedStmt, "call noleggiaFilm(?,?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize request statement\n", false);
	}
	date->day = atoi(day);
	date->month = atoi(month);
	date->year = atoi(year);
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = cliente;
	param[0].buffer_length = strlen(cliente);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = title;
	param[1].buffer_length = strlen(title);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = regista;
	param[2].buffer_length = strlen(regista);
	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &settore;
	param[3].buffer_length = sizeof(settore);
	param[4].buffer_type = MYSQL_TYPE_DATE;
	param[4].buffer = date;
	param[4].buffer_length = sizeof(date);
	param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[5].buffer = myUsername;
	param[5].buffer_length = strlen(myUsername);
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to rent film\n");
		}
		else {
			printf("Properly rented movie\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void inserisciFilm(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[6];
	MYSQL_BIND param1[2];
	char titolo[61];
	char regista[46];
	int settoreI;
	char settore[20];
	int copie;
	char copieC[10];
	char posizione[46];
	printf("Enter the sector code\n");
	leggiNumeri(19, settore);
	settoreI = atoi(settore);
	memset(param1, 0, sizeof(param1));
	param1[0].buffer = myUsername;
	param1[0].buffer_length = strlen(myUsername);
	param1[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param1[1].buffer = &settoreI;
	param1[1].buffer_type = MYSQL_TYPE_LONG;
	param1[1].buffer_length = sizeof(settoreI);
	if (!setup_prepared_stmt(&preparedStmt, "call visualizzaFilmMancanti(?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to procede\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param1) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param\n", true);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, "Unable to show film list\n");
	}
	else {
		dump_result_set(conn, preparedStmt, "Films not present in the center\n");
	}
	mysql_stmt_close(preparedStmt);
	MYSQL_STMT* preparedStmt2;
	printf("Enter the title of the film to be recorded\n");
	getInput(60, titolo, false);
	printf("Enter the director of the film\n");
	getInput(45, regista, false);
	printf("Enter the number of copies\n");
	leggiNumeri(9, copieC);
	printf("Enter the location to register it\n");
	getInput(45, posizione, false);
	copie = atoi(copieC);
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = titolo;
	param[0].buffer_length = strlen(titolo);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = regista;
	param[1].buffer_length = strlen(regista);
	param[2].buffer_type = MYSQL_TYPE_LONG;
	param[2].buffer = &settoreI;
	param[2].buffer_length = sizeof(settoreI);
	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = myUsername;
	param[3].buffer_length = strlen(myUsername);
	param[4].buffer_type = MYSQL_TYPE_LONG;
	param[4].buffer = &copie;
	param[4].buffer_length = sizeof(copie);
	param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[5].buffer = posizione;
	param[5].buffer_length = strlen(posizione);
	if (!setup_prepared_stmt(&preparedStmt2, "call inserisciFilmSettore(?,?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to initialize request statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt2, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to bind param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt2) != 0) {
			print_stmt_error(preparedStmt2, " Unable to insert film\n");
		}
		else {
			printf("Film entered correctly\n");
		}
	}
	mysql_stmt_close(preparedStmt2);
}
void registraCliente(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[7];
	char CF[46];
	char Name[46];
	char Surname[46];
	char day[3];
	char month[3];
	char year[5];
	char address[301];
	MYSQL_TIME* date = (MYSQL_TIME*)malloc(sizeof(MYSQL_TIME));
	strcpy(address, "");
	char var_Telefono[150];
	int goOn = 1;
	char tempAddress[61];
	char scelta;
	strcpy(var_Telefono, "");
	char var_Email[200];
	strcpy(var_Email, "");
	printf("Enter the customer's tax code\n");
	getInput(45, CF, false);
	printf("Enter the customer's name\n");
	getInput(45, Name, false);
	printf("Enter the customer's surname\n");
	getInput(45, Surname, false);
	printf("Enter the date of birth\n");
	printf("Enter the day\n");
	leggiNumeri(2, day);
	printf("Enter the month\n");
	leggiNumeri(2, month);
	printf("Enter the year\n");
	leggiNumeri(4, year);
	printf("Enter the customer's address\n");
	char optAddress[2] = { '1','2' };
	while (goOn) {
		scelta = multiChoice("Choose \n 1)Enter new address\n 2)End\n", optAddress, 2);
		switch (scelta) {
		case '1':
			do {
				printf("Enter the address, the symbol ; is not allowed \n");
				getInput(60, tempAddress, false);
			} while (containsChar(tempAddress, ';')==1);
			strcat(address, tempAddress);
			strcat(address, ";");
			break;
		case '2':
			goOn = 0;
			break;
		}
	}
		goOn = 1;
	printf("Now enter contact details for the customer\n");
	char temp[46];
	char options[3] = { '1','2','3' };
	while (goOn) {
		scelta = multiChoice("Choose \n 1)Enter telephone number\n 2)Enter email\n 3)End\n", options, 3);
		switch (scelta) {
		case '1':
			printf("Enter the telephone number\n");
			leggiNumeri(15, temp);
			if (strlen(var_Telefono) +strlen(temp)> 100) {
				printf("You have reached the maximum number of phone numbers that can be registered, you will be able to register others later\n");
			}
			else {
				strcat(var_Telefono, temp);
				strcat(var_Telefono, ";");
			}
			break;
		case '2':
			printf("Enter the email\n");
			getInput(45, temp, false);
			if(strlen(var_Email)+strlen(temp)>200){
				printf("You have reached the maximum number of emails that can be registered, you will be able to register others later\n");
			}
			else {
				strcat(var_Email, temp);
				strcat(var_Email, ";");
			}
			break;
		case '3':
			goOn = 0;
			break;
		}
	}
	date->day = atoi(day);
	date->month = atoi(month);
	date->year = atoi(year);
	if (!setup_prepared_stmt(&preparedStmt, "call registraCliente(?,?,?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize insert statement\n", false);
	}
	memset(param, 0, sizeof(param));
	param[0].buffer = CF;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(CF);
	param[1].buffer = Name;
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer_length = strlen(Name);
	param[2].buffer = address;
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer_length = strlen(address);
	param[3].buffer = Surname;
	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer_length = strlen(Surname);
	param[4].buffer = var_Telefono;
	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer_length = strlen(var_Telefono);
	param[5].buffer = var_Email;
	param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[5].buffer_length = strlen(var_Email);
	param[6].buffer = date;
	param[6].buffer_type = MYSQL_TYPE_DATE;
	param[6].buffer_length = sizeof(date);
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to insert client\n");
		}
		else {
			printf("Customer entered correctly\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void timbraCartellino(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[1];
	memset(param, 0, sizeof(param));
	param[0].buffer = myUsername;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(myUsername);
	if (!setup_prepared_stmt(&preparedStmt, "call timbra(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize request statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param for statement\n", true);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, " Impossible to stamp the card\n");
	}
	else {
		printf("Operation succeded\n");
	}
	mysql_stmt_close(preparedStmt);
}
void vediTurno(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[1];
	memset(param, 0, sizeof(param));
	param[0].buffer = myUsername;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(myUsername);
	if (!setup_prepared_stmt(&preparedStmt, "call visualizzaTurno(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize request statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param for statement\n", true);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, " Unable to execute query for turno di lavoro\n");
	}
	else {
		dump_result_set(conn, preparedStmt, "Workshift");
	}
	mysql_stmt_close(preparedStmt);
}
void apriMenuCliente(MYSQL* conn) {
	char option[5] = { '1','2','3','4','5' };
	char choice;
	while (true) {
		choice = multiChoice("Customer menu\n Choose the operation: 1)View expired orders\n 2)Search for a customer\n 3) Insert email,telephone number or address\n4)Remove customer\n5)Return to the main menu\n", option, 5);
		switch (choice) {
		case '1':
			visualizzaTitoliScaduti(conn);
			break;

		case '2':
			cercaCliente(conn);
			break;
		case '3':
			handle_client(conn);
			break;
		case '4':
			remove_client(conn);
		case '5':
			return;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
		}
	}
}
void menu_film(MYSQL* conn) {
	char scelta;
	char opt[3] = { '1','2','3' };
	while (true) {
		scelta = multiChoice("Choose the operation\n: 1)Order new copies for a film\n 2)Order a new type of film\n 3)Exit\n",opt,3);
		switch (scelta) {
		case '1':
			update_copy(conn);
			break;
		case '2':
			inserisciFilm(conn);
			break;
		case '3':
			return;
		}
	}
}
void run_as_employer(MYSQL* conn, char* username) {
	strcpy(myUsername, username);
	char risp;
	printf("Switching to employer role...\n");
	int res;
	if (!parse_config("users/employer.json", &conf)) {
		fprintf(stderr, "Unable to load employer configuration\n");
		exit(EXIT_FAILURE);
	}

	if (mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}
	timbraCartellino(conn);
	char options[9] = { '1','2','3','4','5','6','7','8','9' };
	printf("\033[2J\033[H");
	char* question = "Choose the operation:\n 1) View workshift\n 2) Stamp card\n3)Register customer\n 4)Rent movies\n5)Record film return\n6)Order movies\n7)Open customer menu\n8)Remove film from center\n9)exit";
	while (true) {
		risp = multiChoice(question, options, 9);
		switch (risp) {
		case '1':
			vediTurno(conn);
			break;
		case '2':
			timbraCartellino(conn);
			break;
		case '3':
			registraCliente(conn);
			break;
		case '4':
			noleggiaFilm(conn);
			break;
		case '5':
			restituisciFilm(conn);
			break;
		case '6':
			menu_film(conn);
			break;
		case '7' :
			apriMenuCliente(conn);
			break;
		case '8':
			rimuoviFilmSettore(conn);
			break;
		case '9':
			timbraCartellino(conn);
			return;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
		}

	}
}