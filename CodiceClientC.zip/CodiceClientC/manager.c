#include "defines.h"
#include<stdio.h>
#include<stdlib.h>
void inserisciTurnoDiLavoro(MYSQL* conn, char* employer);
int is_valid_time(char* time) {
	char hour[3];
	char minute[3];
	int i = 0;
	if (strlen(time) != 5) {
		printf("Insert a valid time\n");
		return 0;
	}
	hour[0] = time[0];
	hour[1] = time[1];
	hour[2] = '\0';
	minute[0] = time[3];
	minute[1] = time[4];
	minute[2] = '\0';
	int hourI = atoi(hour);
	int minuteI = atoi(minute);
	if (hourI >= 0 && hourI <= 23 && minuteI >= 0 && minuteI <= 59) {
		return 1;
	}
	printf("Insert a valid time\n");
	return 0;
}
int parse_date(MYSQL* conn, MYSQL_STMT* stmt, char** date) {
	MYSQL_TIME date_inizio;
	MYSQL_TIME date_concluso;
	MYSQL_BIND param[2];
	int is_null = 0;
	if (mysql_stmt_store_result(stmt)) {
		fprintf(stderr, " mysql_stmt_execute(), 1 failed\n");
		fprintf(stderr, " %s\n", mysql_stmt_error(stmt));
		exit(0);
	}
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_DATE;
	param[0].buffer = &date_inizio;
	param[0].buffer_length = sizeof(date_inizio);
	param[1].buffer_type = MYSQL_TYPE_DATE;
	param[1].buffer = &date_concluso;
	param[1].buffer_length = sizeof(date_concluso);
	param[1].is_null = &is_null;
	if (mysql_stmt_bind_result(stmt, param)) {
		if (mysql_stmt_next_result == 0) {
			finish_with_stmt_error(conn, stmt, "Unable to bind column parameters\n", true);
		}
		else {
			return 0;
		}
	}
	mysql_stmt_fetch(stmt);
	date[0] = (char*)malloc(sizeof(char) * 12);
	sprintf(date[0], " %d-%02d-%02d", date_inizio.year, date_inizio.month, date_inizio.day);
	if (is_null) {
		date[1] = (char*)malloc(sizeof(char) * strlen("IN PROGRESS")+1);
		strcpy(date[1], "IN PROGRESS");
	}
	else {
		date[1] = (char*)malloc(sizeof(char) * 12);
		sprintf(date[1], " %d-%02d-%02d", date_concluso.year, date_concluso.month, date_concluso.day);
	}
	return 1;
}
int visualizzaImpiegati(MYSQL* conn, char** cf,int max) {
	MYSQL_STMT* preparedStmt;
	if (!setup_prepared_stmt(&preparedStmt, "call visualizzaImpiegati()", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize employer list", false);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, " Unable to read data\n");
	}
	int res=dump_result_set_with_list(conn, preparedStmt, "Employers\n",cf,max);
	mysql_stmt_close(preparedStmt);
	return res;
}
void rimuoviImpiegato(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[1];
	char username[46];
	char** cf = (char**)malloc(sizeof(char*) * 200);
	if (cf == NULL) {
		printf("Unable to execute malloc\n");
		exit(0);
	}
	int dim = visualizzaImpiegati(conn, cf, 200);
	if (dim == 0) {
		printf("There are no employers\n");
		return;
	}
	printf("Now insert employer username\n");
	getInput(45, username, false);
	memset(param, 0, sizeof(param));
	param[0].buffer = username;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(username);
	if (!yesOrNo("Are you sure you want to delete this employer?"))
		return;
	if (!setup_prepared_stmt(&preparedStmt, "call rimuoviImpiegato(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize operation", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param ", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, "Unable to remove employer");
		}
		else {
			printf("Employer successfully removed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void reportAnnuale(MYSQL* conn) {
	int onFile = 0;
	HANDLE hOut = NULL;
	MYSQL_STMT* preparedStmt;
	HANDLE fileHandler = GetStdHandle(STD_OUTPUT_HANDLE);
	MYSQL_BIND param[3];
	int risp = yesOrNo("Do you want to see full list of employer?\n");
	char CF[46];
	char fileName[46];
	char** date = (char**)malloc(sizeof(char*) * 2);
	char header[1024];
	char month[6];
	int turno = 0;
	if (risp == 1) {
		char** cf = (char**)malloc(sizeof(char*) * 200);
		if (cf == NULL) {
			printf("Unable to execute malloc\n");
			exit(0);
		}
		char risposta[1024];
		int dim=visualizzaImpiegati(conn,cf,200);
		if (dim == 0) {
			printf("There are no employers\n");
			return;
		}
		do {
			printf("Enter the number of the chosen employee\n");
			leggiNumeri(dim, risposta);
		} while (atoi(risposta) >= dim);
		strcpy(CF, cf[atoi(risposta)]);
		free(cf);
	}
	else {
		printf("Enter the employee's tax code\n");
		getInput(45, CF, false);
	}
	printf("Enter the year\n");
	leggiNumeri(5, month);
	int m = atoi(month);
	turno = yesOrNo("Do you also want to see all the work shifts for this employee?\n");
	memset(param, 0, sizeof(param));
	param[0].buffer = CF;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(CF);
	param[1].buffer_type = MYSQL_TYPE_SHORT;
	param[1].buffer = &m;
	param[1].buffer_length = sizeof(m);
	param[2].buffer_type = MYSQL_TYPE_SHORT;
	param[2].buffer = &turno;
	param[2].buffer_length = sizeof(turno);
	if (!setup_prepared_stmt(&preparedStmt, "call reportAnnuale(?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize ", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param ", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, "Unable to read data\n");
		}
		else {
			onFile = yesOrNo("Do you want to save results on a file?\n");
			if (onFile) {
				printf("Insert the file name, the file will be saved in the reports directory\n");
				getInput(45, fileName, false);
				char finalPath[60];
				strcpy(finalPath, "reports/");
				strcat(finalPath, fileName);
				fileHandler = CreateFile(
					finalPath,
					GENERIC_READ | GENERIC_WRITE,
					0,
					NULL,
					CREATE_ALWAYS,
					FILE_ATTRIBUTE_NORMAL,
					NULL
				);
			}
			while (conn->server_status & SERVER_PS_OUT_PARAMS) {
			}
			dump_multiple_rs(conn, preparedStmt, "Annual report\n",fileHandler);
			while (mysql_stmt_next_result(preparedStmt) == 0) {
				if (parse_date(conn, preparedStmt, date)) {
					sprintf(header, "Workshift From:%s to:%s", date[0], date[1]);
					if (mysql_stmt_next_result(preparedStmt) > 0) {
						finish_with_stmt_error(conn, preparedStmt, "Unexpected condition", true);
					}
					dump_multiple_rs(conn, preparedStmt, header,fileHandler);
				}
				else {
					break;
				}
			}
			if (onFile) {
				CloseHandle(fileHandler);
				printf("Saved\n");
			}
		}
	}
	mysql_stmt_close(preparedStmt);
}
void reportMensile(MYSQL* conn) {
	HANDLE fileHandler = GetStdHandle(STD_OUTPUT_HANDLE);
	int onFile = 0;
	char fileName[46];
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[3];
	char year[5];
	char header[1024];
	char** date = (char**)malloc(sizeof(char*) * 2);
	int contatoreTurni = 0;
	char CF[46];
	char month[3];
	int risp = yesOrNo("Do you want to see full list of employer?\n");
	if (risp == 1) {
		char** cf = (char**)malloc(sizeof(char*) * 200);
		if (cf == NULL) {
			printf("Unable to execute malloc\n");
			exit(0);
		}
		char risposta[1024];
		int dim = visualizzaImpiegati(conn, cf, 200);
		if (dim == 0) {
			printf("There are no employers\n");
			return;
		}
		do {
			printf("Enter the number of the chosen employee\n");
			leggiNumeri(dim, risposta);
		} while (atoi(risposta) >= dim);
		strcpy(CF, cf[atoi(risposta)]);
		free(cf);
	}
	else {
		printf("Enter the employee's tax code\n");
		getInput(45, CF, false);
	}
	printf("Enter the month\n");
	leggiNumeri(2, month);
	printf("Enter the year\n");
	leggiNumeri(4, year);
	int m = atoi(month);
	int y = atoi(year);
	printf("%d", m);
	memset(param, 0, sizeof(param));
	param[0].buffer = CF;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(CF);
	param[1].buffer_type = MYSQL_TYPE_SHORT;
	param[1].buffer = &m;
	param[1].buffer_length = sizeof(m);
	param[2].buffer_type = MYSQL_TYPE_SHORT;
	param[2].buffer = &y;
	param[2].buffer_length = sizeof(y);
	if (!setup_prepared_stmt(&preparedStmt, "call reportMensile(?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize ", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to bind param ", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to read data\n");
		}
		else {
			onFile = yesOrNo("Do you want to save results on a file?\n");
			if (onFile) {
				printf("Insert the file name, the file will be saved in the reports directory\n");
				getInput(45, fileName, false);
				char finalPath[60];
				strcpy(finalPath, "reports/");
				strcat(finalPath, fileName);
				fileHandler = CreateFile(
					finalPath,
					GENERIC_READ | GENERIC_WRITE,
					0,
					NULL,
					CREATE_ALWAYS,
					FILE_ATTRIBUTE_NORMAL,
					NULL
				);
			}
			while (conn->server_status & SERVER_PS_OUT_PARAMS) {
			}
			dump_multiple_rs(conn, preparedStmt, "report Mensile\n",fileHandler);
			while (mysql_stmt_next_result(preparedStmt) == 0) {
				if (parse_date(conn, preparedStmt, date)) {
					sprintf(header, "Workshift From:%s to:%s", date[0], date[1]);
					if (mysql_stmt_next_result(preparedStmt) > 0) {
						finish_with_stmt_error(conn, preparedStmt, "Unexpected condition", true);
					}
					dump_multiple_rs(conn, preparedStmt, header,fileHandler);
					contatoreTurni++;
				}
				else {
					break;
				}
			}
			if (onFile) {
				CloseHandle(fileHandler);
				printf("Saved\n");
			}
		}
	}
	mysql_stmt_close(preparedStmt);
}
void visualizzaCentri(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	if (!setup_prepared_stmt(&preparedStmt, "call visualizzaCentri()", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize center list", false);
	}
	if (mysql_stmt_execute(preparedStmt) != 0) {
		print_stmt_error(preparedStmt, " Unable to read data\n");
	}
	dump_result_set(conn, preparedStmt, "Centers\n");
	mysql_stmt_close(preparedStmt);
}
int vectorContains(char c, char* vector, int length) {
	int i = 0;
	for (i = 0; i < length; i++) {
		if (c == vector[i])
			return 1;
	}
	return 0;
}
void leggiInfoTurno(char* days, char* hours,  MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	char scelta;
	char hour[6];
	strcpy(days, "");
	strcpy(hours, "");
	char options[7] = { '1','2','3','4','5','6','7' };
	char giorniScelti[7];
	int count = 0;
	int goOn = 1;
	while (goOn == 1) {
		while (1) {
			scelta = multiChoice("Choose a day 1)Monday\n2)Tuesday\n3)Wednesday\n4)Thursday\n5)Friday\n6)Saturday\n7)Exit", options, 7);
			if (vectorContains(scelta, giorniScelti, 7)) {
				printf("You have already chosen this day\n");
			}
			else {
				break;
			}
		}
		switch (scelta) {
		case '1':
			strcat(days, "Monday;");
			break;
		case '2':
			strcat(days, "Tuesday;");
			break;
		case '3':
			strcat(days, "Wednesday;");
			break;
		case '4':
			strcat(days, "Thursday;");
			break;
		case '5':
			strcat(days, "Friday;");
			break;
		case '6':
			strcat(days, "Saturday;");
			break;
		case '7':
			goOn = 0;
			break;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
		}
		giorniScelti[count] = scelta;
		count++;
		if (goOn == 1) {
			do {
				inserisciOrario("Enter start time\n", hour, 6);
			} while (!is_valid_time(hour));
			strcat(hours, hour);
			strcat(hours, ";");
			do {
				inserisciOrario("Enter end time\n", hour, 6);
			} while (!is_valid_time(hour));
			strcat(hours, hour);
			strcat(hours, ";");
		}

	}
}
void inserisciTurnoDiLavoro(MYSQL* conn,char* impiegato) {
	MYSQL_STMT* preparedStmt2;
	MYSQL_BIND param[3];
	
	char days[140];
	char hours[100];
	char employer[46];
	char** cf = (char**)malloc(sizeof(char*) * 200);
	if (cf == NULL) {
		printf("Unable to execute malloc\n");
		exit(0);
	}
	char risposta[1024];
	int dim = visualizzaImpiegati(conn, cf, 200);
	if (dim == 0) {
		printf("There are no employers\n");
		return;
	}
	do {
		printf("Enter the number of the chosen employee\n");
		leggiNumeri(dim, risposta);
	} while (atoi(risposta) >= dim);
	strcpy(employer, cf[atoi(risposta)]);
	free(cf);
	leggiInfoTurno(days, hours,  conn);
	

	if (!setup_prepared_stmt(&preparedStmt2, "call inserisciTurnoDiLavoro(?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to initialize turno di lavoro insertion statement\n", false);
	}
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = employer;
	param[0].buffer_length = strlen(employer);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = days;
	param[1].buffer_length = strlen(days);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = hours;
	param[2].buffer_length = strlen(hours);
	if (mysql_stmt_bind_param(preparedStmt2, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt2, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt2) != 0) {
			print_stmt_error(preparedStmt2, " Unable to execute insert\n");
		}
		else {
			printf("\nShift registered successfully\n");
		}
	}
	mysql_stmt_close(preparedStmt2);
}
void spostaImpiegato(MYSQL* conn, char* empl) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[5];
	char impiegato[46];
	int centro;
	char centroS[20];
	char role[45];
	char days[140];
	char hours[100];
	if (empl == NULL) {
		char** cf = (char**)malloc(sizeof(char*) * 200);
		if (cf == NULL) {
			printf("Unable to execute malloc\n");
			exit(0);
		}
		char risposta[1024];
		int dim = visualizzaImpiegati(conn, cf, 200);
		if (dim == 0) {
			printf("There are no employers\n");
			return;
		}
		do {
			printf("Enter the number of the chosen employee\n");
			leggiNumeri(dim, risposta);
		} while (atoi(risposta) >= dim);
		strcpy(impiegato, cf[atoi(risposta)]);
		free(cf);
	}
	else {
		strcpy(impiegato, empl);
	}
	visualizzaCentri(conn);
	printf("Insert center code\n");
	leggiNumeri(19, centroS);
	printf("Insert role\n");
	getInput(45, role, false);
	centro = atoi(centroS);
	printf("Now insert work shift\n");
	leggiInfoTurno(days, hours, conn);
	if (!setup_prepared_stmt(&preparedStmt, "call registraImpiego(?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize employer impiego insertion statement\n", false);
	}
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = impiegato;
	param[0].buffer_length = strlen(impiegato);
	param[1].buffer_type = MYSQL_TYPE_LONG;
	param[1].buffer = &centro;
	param[1].buffer_length = sizeof(centro);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = role;
	param[2].buffer_length = strlen(role);
	param[3].buffer = days;
	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer_length = strlen(days);
	param[4].buffer = hours;
	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer_length = strlen(hours);
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to execute insert\n");
		}
		else {
			printf("\nJob successfully registered\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}

void registraImpiegato(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[11];
	char name[46];
	char cf[46];
	char cognome[46];
	char recapito[46];
	char titoloStudio[61];
	char username[46];
	char password[46];
	char centerC[10];
	int center;
	char hours[100];
	char days[140];
	char role[46];
	printf("Insert employer CF\n");
	getInput(45, cf, false);
	printf("Insert employer name\n");
	getInput(45, name, false);
	printf("Inserisci employer surname\n");
	getInput(45, cognome, false);
	char rec[2] = { '1','2' };
	char sceltaR=multiChoice("Now enter contact details for the employee, choose between 1) Telephone number 2) Email address\n", rec, 2);
	if (sceltaR == '1') {
		printf("Enter the phone number\n");
		leggiNumeri(10, recapito, false);
	}
	else {
		printf("Enter the email address\n");
		getInput(45, recapito, false);
	}
	printf("Insert employer title\n");
	getInput(60, titoloStudio, false);
	printf("Insert employer username\n");
	getInput(45, username, false);
	printf("Insert employer password\n");
	getInput(45, password, true);
	printf("Now insert employer center\n");
	visualizzaCentri(conn);
	leggiNumeri(9, centerC);
	center = atoi(centerC);
	printf("Now insert employer role\n");
	getInput(45, role, false);
	printf("Now insert workshift\n");
	leggiInfoTurno(days, hours, conn);
	if (!setup_prepared_stmt(&preparedStmt, "call registraImpiegato(?,?,?,?,?,?,?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize employer insertion statement\n", false);
	}
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = cf;
	param[0].buffer_length = strlen(cf);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = name;
	param[1].buffer_length = strlen(name);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = recapito;
	param[2].buffer_length = strlen(recapito);
	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = titoloStudio;
	param[3].buffer_length = strlen(titoloStudio);
	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = username;
	param[4].buffer_length = strlen(username);
	param[5].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[5].buffer = password;
	param[5].buffer_length = strlen(password);
	param[6].buffer = days;
	param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[6].buffer_length = strlen(days);
	param[7].buffer = hours;
	param[7].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[7].buffer_length = strlen(hours);
	param[8].buffer = &center;
	param[8].buffer_type = MYSQL_TYPE_LONG;
	param[8].buffer_length = sizeof(center);
	param[9].buffer = role;
	param[9].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[9].buffer_length = strlen(role);
	param[10].buffer = cognome;
	param[10].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[10].buffer_length = strlen(cognome);
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to execute insert\n");
		}
		else {
			printf("\nEmployee entered correctly\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}

void run_as_manager(MYSQL* conn,int isAdmin) {
	char risp;
	char** cf = (char**)malloc(sizeof(char*) * 200);
	if (cf == NULL) {
		printf("Unable to execute malloc\n");
		exit(0);
	}
	if (!isAdmin) {
		printf("Switching to manager role...\n");
		int res;
		if (!parse_config("users/manager.json", &conf)) {
			fprintf(stderr, "Unable to load manager configuration\n");
			exit(EXIT_FAILURE);
		}

		if (mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
			fprintf(stderr, "mysql_change_user() failed\n");
			exit(EXIT_FAILURE);
		}
	}
	CreateDirectoryA(
		"reports",
		NULL
	);
	char options[8] = { '1','2','3','4','5','6','7','8' };
	printf("\033[2J\033[H");
	char* question = "Choose operation:\n 1) Register Employee \n 2) Move an Employee from office or assign a new role \n3) Enter work shift \n 4) View monthly report \n5) View annual report \n6) view Employees \n7) Remove Employee \n8) exit";
	while (true) {
		risp = multiChoice(question, options, 8);
		switch (risp) {
		case '1':
			registraImpiegato(conn);
			break;
		case '2':
			spostaImpiegato(conn,NULL);
			break;
		case '3':
			inserisciTurnoDiLavoro(conn,NULL);
			break;
		case '4':
			reportMensile(conn);
			break;
		case '5':
			reportAnnuale(conn);
			break;
		case '6':
			visualizzaImpiegati(conn, cf, 200);
			break;
		case '7':
			rimuoviImpiegato(conn);
			break;
		case '8':
			return;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
		}
		
	}
}