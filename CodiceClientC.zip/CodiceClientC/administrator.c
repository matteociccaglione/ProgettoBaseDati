#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"
#define MAX_TEL 100
#define MAX_EMAIL 450
int contains(char* string, char character) {
	int c = 0;
	while (string[c] != '\0') {
		if (string[c] == character) {
			return true;
		}
		c++;
	}
	return false;
}
void handle_center(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[2];
	char result[46];
	char center[40];
	int id;
	char store_procedure[1024];
	char opt[3] = { '1','2','3' };
	char scelta = multiChoice("Scegli 1)Enter new telephone number\n,2)Enter new email\n,3) Exit", opt, 3);
	switch (scelta) {
	case'1':
		strcpy(store_procedure, "call inserisciTelefonoCentro(?,?)");
		printf("Enter the telephone number\n");
		leggiNumeri(10, result);
		break;
	case '2':
		strcpy(store_procedure, "call inserisciEmailCentro(?,?)");
		printf("Enter the email\n");
		getInput(45, result, false);
		break;
	case '3':
		return;
	}
	printf("Enter the code of the center\n");
	leggiNumeri(39, center);
	id = atoi(center);
	memset(param, 0, sizeof(param));
	param[0].buffer = &id;
	param[0].buffer_length = sizeof(id);
	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[1].buffer = result;
	param[1].buffer_length = strlen(result);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	if (!setup_prepared_stmt(&preparedStmt, store_procedure, conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Failed to initialize statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Cannot set parameters\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to insert\n");
		}
		else {
			printf("Update completed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void rimuoviManager(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[1];
	char usernameManager[46];
	printf("Enter the username of the manager to remove\n");
	getInput(45, usernameManager, false);
	memset(param, 0, sizeof(param));
	param[0].buffer = usernameManager;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(usernameManager);
	if (!setup_prepared_stmt(&preparedStmt, "call rimuoviManager(?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize  rimozione manager statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to remove manager\n");
		}
		else {
			printf("\nManager removed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
int containsPoint(char* string) {
	int i;
	int found = 0;
	//Return 0 if the string not contains point, 1 if the string contains one point and -1 if the string is malformed
	for (i = 0; i < strlen(string); i++) {
		if (string[i] == '.' && !found) {
			found = 1;
		}
		else {
			if (string[i] < 48 || string[i]>57) {
				return -1;
			}
		}
	}
	if (found == 1) 
		return -1;
	return found;
}
void inserisciFilmCatalogo(MYSQL* conn) {
	/*
		Il carattere ; non è ammesso perché utilizzato come delimitatore di stringa nelle store procedure
	*/
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[8];
	char titolo[61];
	char regista[46];
	char yearC[5];
	char type[46];
	char costoC[10];
	double costo;
	char remakeTitolo[601];
	char remakeRegista[451];
	strcpy(remakeTitolo, "");
	strcpy(remakeRegista, "");
	printf("\nInsert title\n");
	getInput(60, titolo, false);
	printf("\nEnter the director\n");
	getInput(45, regista, false);
	char options[3] = { '1','2','3' };
	char scelta=multiChoice("Insert type 1) New\n 2) Classic\n 3) Other\n", options, 3);
	switch (scelta) {
		case '1':
			strcpy(type, "nuovo");
			break;
		case '2':
			strcpy(type, "classico");
			break;
		case '3':
			strcpy(type, "other");
			break;
	}
	printf("Enter the year of publication\n");
	leggiNumeri(4, yearC);
	printf("Enter the list of actors reporting the full name for each actor\n");
	int goOn = 1;
	char options1[2] = { '1','2' };
	char temp[46];
	char attori[1000];
	strcpy(attori, "");
	while (goOn) {
		scelta = multiChoice("Type 1 to insert an actor or 2 to end\n", options, 2);
		switch (scelta) {
			case '1':
				do {
					printf("Enter the actor's full name (the character; is not allowed)\n");
					getInput(45, temp, false);
				} while (contains(temp, ';'));
				strcat(attori, temp);
				strcat(attori, ";");
				break;
			case '2':
				goOn = 0;
				break;
		}
	}
	printf("Insert the films of which the inserted film is a remake\n");
	goOn = 1;
	while (goOn) {
		scelta = multiChoice("Enter 1 to insert a movie or 2 to end\n", options, 2);
		switch (scelta) {
		case '1':
			
			do {
				printf("Enter the movie title, the character; it is not allowed\n");
				getInput(60, temp, false);
			} while (contains(temp, ';'));
			strcat(remakeTitolo, temp);
			strcat(remakeTitolo, ";");
			do {
				printf("Enter the director of the film\n");
				getInput(45, temp, false);
				strcat(remakeRegista, temp);
				strcat(remakeRegista, ";");
			}while(contains(temp,';'));
			break;
		case '2':
			goOn = 0;
			break;
		}
	}
	do {
		printf("Inserisci il costo del film\n");
		getInput(9, costoC, false);
	} while (containsPoint(costoC) == -1);
	if (!containsPoint(costoC)) {
		strcat(costoC, ".");
		strcat(costoC, "0");
	}
	costo = atof(costoC);
	MYSQL_TIME* date = (MYSQL_TIME*)malloc(sizeof(MYSQL_TIME));
	if (date == NULL) {
		printf("Error malloc\n");
		exit(0);
	}
	date->day = 1;
	date->month = 1;
	date->year = atoi(yearC);
	memset(param, 0, sizeof(param));
	param[0].buffer = titolo;
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer_length = strlen(titolo);
	param[1].buffer = regista;
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer_length = strlen(regista);
	param[2].buffer = type;
	param[2].buffer_length = strlen(type);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = date;
	param[3].buffer_type = MYSQL_TYPE_DATE;
	param[3].buffer_length = sizeof(date);
	param[4].buffer = attori;
	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer_length = strlen(attori);
	param[5].buffer_type = MYSQL_TYPE_DOUBLE;
	param[5].buffer = &costo;
	param[5].buffer_length = sizeof(costo);
	param[6].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[6].buffer = remakeTitolo;
	param[6].buffer_length = strlen(remakeTitolo);
	param[7].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[7].buffer = remakeRegista;
	param[7].buffer_length = strlen(remakeRegista);
	if (!setup_prepared_stmt(&preparedStmt, "call inserireFilmCatalogo(?,?,?,?,?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize settore insertion statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to insert film\n");
		}
		else {
			printf("\nFilm correctly added\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void rimuoviFilm(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[2];
	char titolo[61];
	char regista[46];
	printf("\nEnter the title of the movie\n");
	getInput(60, titolo, false);
	printf("\nEnter the director\n");
	getInput(45, regista, false);
	memset(param, 0, sizeof(param));
	param[0].buffer = titolo;
	param[0].buffer_length = strlen(titolo);
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = regista;
	param[1].buffer_length = strlen(regista);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	if (!setup_prepared_stmt(&preparedStmt, "call rimuoviFilm(?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize settore insertion statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to remove film\n");
		}
		else {
			printf("\nFilm correctly removed\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void registraSettore(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[2];
	int centerCode;
	int settoreCode;
	char code[20];
	char settore[20];
	printf("\033[2J\033[H");
	printf("\nInsert center code\n");
	leggiNumeri(19, code);
	printf("\nInsert sector code\n");
	leggiNumeri(19, settore);
	centerCode = atoi(code);
	settoreCode = atoi(settore);
	if (!setup_prepared_stmt(&preparedStmt, "call inserisciSettore(?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize settore insertion statement\n", false);
	}
	memset(param, 0, sizeof(param));
	param[1].buffer_type = MYSQL_TYPE_LONG;
	param[1].buffer = &centerCode;
	param[1].buffer_length = sizeof(centerCode);
	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &settoreCode;
	param[0].buffer_length = sizeof(settoreCode);
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, " Unable to execute insert\n");
		}
		else {
			printf("\nSector entered correctly\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void registraCentro(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[4];
	int codeI;
	char indirizzo[61];
	char responsabile[46];
	char telefono[101];
	strcpy(telefono, "");
	char email[451];
	strcpy(email, "");
	char scelta;
	char temp[46];
	char opt[2] = { '1','2' };
	int goOn;
	char code[20];
	printf("\033[2J\033[H");
	printf("\nInsert Address\n");
	getInput(60, indirizzo, false);
	printf("\nInsert Responsible\n");
	getInput(45, responsabile, false);
	goOn = 1;
	printf("\nEnter phone numbers\n");
	while (goOn) {
		scelta = multiChoice("Choose 1) Enter telephone number\n2)End\n", opt, 2);
		switch (scelta) {
		case '1':
			printf("Enter the telephone number\n");
			leggiNumeri(10, temp);
			if (strlen(telefono) + strlen(temp) > MAX_TEL) {
				printf("You have exceeded the maximum number of phone numbers that can be entered, you can enter the remaining ones later\n");
				goOn = 0;
			}
			else {
				strcat(telefono, temp);
				strcat(telefono, ";");
			}
			break;
		case '2':
			goOn = 0;
			break;
		}
	}
	goOn = 1;
	printf("\nEnter the email\n");
	while (goOn) {
		scelta = multiChoice("Choose 1) Enter email \n2) Finish\n", opt, 2);
		switch (scelta) {
		case '1':
			printf("Enter email\n");
			getInput(45, temp,false);
			if (strlen(email) + strlen(temp) > MAX_EMAIL) {
				printf("You have exceeded the maximum number of emails that can be entered, you can enter the remaining ones later\n");
				goOn = 0;
			}
			else {
				strcat(email, temp);
				strcat(email, ";");
			}
			break;
		case '2':
			goOn = 0;
			break;
		}
	}
	memset(param, 0, sizeof(param));
	
	
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = indirizzo;
	param[0].buffer_length = strlen(indirizzo);
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = responsabile;
	param[1].buffer_length = strlen(responsabile);
	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = telefono;
	param[2].buffer_length = strlen(telefono);
	
	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = email;
	param[3].buffer_length = strlen(email);
	if (!setup_prepared_stmt(&preparedStmt, "call inserisciCentro(?,?,?,?)", conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize center insertion statement\n", false);
	}
	if (mysql_stmt_bind_param(preparedStmt, param) != 0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, "An error has occured while adding center\n");
		}
		else {
			printf("\nCenter correctly added\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void registraUtente(MYSQL* conn) {
	MYSQL_STMT* preparedStmt;
	MYSQL_BIND param[3];
	char username[46];
	char password[46];
	char role[46];
	char options[2] = { '1','2' };
	char risp;
	printf("\033[2J\033[H");
	printf("\nInsert Username: \n");
	getInput(45, username, false);
	printf("\nInsert Password: \n");
	getInput(45, password, true);
	printf("\n Choose a role\n 1)administrator\n2)manager\n");
	risp = multiChoice("Select role ", options, 2);
	printf("%c", risp);
	switch (risp) {
	case '1':
		strcpy(role, "administrator");
		break;
	case '2':
		strcpy(role, "manager");
		break;
	default:
		fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
		abort();
	}
	if (!setup_prepared_stmt(&preparedStmt, "call creaUtente(?,?,?)",conn)) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to initialize user insertion statement\n", false);
	}
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);
	
	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = password;
	param[1].buffer_length = strlen(password);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = role;
	param[2].buffer_length = strlen(role);

	if (mysql_stmt_bind_param(preparedStmt, &param)!=0) {
		finish_with_stmt_error(conn, preparedStmt, "Unable to setup param\n", true);
	}
	if (areYouSure()) {
		if (mysql_stmt_execute(preparedStmt) != 0) {
			print_stmt_error(preparedStmt, "An error has occured while adding user\n");
		}
		else {
			printf("\nUser correctly added\n");
		}
	}
	mysql_stmt_close(preparedStmt);
}
void run_as_administrator(MYSQL* conn){
	char risp;
	printf("Switching to administrative role...\n");
	int res;
	if(!parse_config("users/administrator.json", &conf)) {
		fprintf(stderr, "Unable to load administrator configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}
	char options[9] = { '1','2','3','4','5','6','7','8','9'};
	printf("\033[2J\033[H");
	char* questions = "Choose the operation to perform: \n 1) registerUser, \n 2) registerCenter, \n 3) registerSector \n 4) Remove movie from catalog \n 5) Update chain catalog \n6) Remove Manager \n 7) Go to menu manager \n8) Manage center \n 9) exit\n";
	while (true) {
		
		risp = multiChoice(questions, options, 9);
		switch (risp) {
		case '1':
			registraUtente(conn);
			break;
		case '2':
			registraCentro(conn);
			break;
		case '3':
			registraSettore(conn);
			break;
		case '4':
			rimuoviFilm(conn);
			break;
		case '5':
			inserisciFilmCatalogo(conn);
			break;
		case '6':
			rimuoviManager(conn);
			break;
		case '7':
			run_as_manager(conn,1);
			break;
		case '8':
			handle_center(conn);
			break;
		case '9':
			return;
		default:
			fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
			abort();
		}
		
	}
}