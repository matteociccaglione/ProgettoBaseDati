#include<stdio.h>
#include<stdlib.h>
#include <windows.h>
#include <stdbool.h>
#include "defines.h"
int getInput(int lenght, char* string, bool hide) {
	const char BACKSPACE = 8;
	const char RETURN = 13;
	unsigned char ch = 0;
	DWORD con_mode;
	DWORD dwRead;
	int i = 0;
	HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);

	GetConsoleMode(hIn, &con_mode);
	SetConsoleMode(hIn, con_mode & ~(ENABLE_ECHO_INPUT | ENABLE_LINE_INPUT));
insert:		while (ReadConsoleA(hIn, &ch, 1, &dwRead, NULL) && ch != RETURN) {
			if (ch == BACKSPACE)
			{
				if (i != 0) {
					printf("\b \b");
					string[i - 1] = '\0';
					i--;
				}
			}
			else {
				if (i < lenght) {
					string[i] = ch;
					if (hide)
						printf("*");
					else
						printf("%c", ch);
					i++;
				}
			}

		}
	printf("\n");
	if (i == 0) {
		printf("You must enter at least one character\n");
		goto insert;
	}
	string[i] = '\0';
	SetConsoleMode(hIn, con_mode);
	if (strlen(string) <= 1)
		return 0;
	return 1;
}
char multiChoice(char* question, char options[], int num_Options) {
	int i = 0, j = 0;
	char* answer = (char*)malloc(sizeof(char) * 2);
	char* poss = (char*)malloc(sizeof(char) * num_Options + 2);
	for (i = 0; i < num_Options; i++) {
		poss[j] = options[i];
		j++;
		poss[j] = '/';
		j++;
	}
	poss[j - 1] = '\0';
	while (true) {
		printf("\n %s: \n[%s]\n", question, poss);
		getInput(1, answer, false);
		for (i = 0; i < num_Options; i++) {
			if (answer[0] == options[i])
				return answer[0];
		}
		printf("Stick to the options provided\n");
	}
}
	int inserisciOrario(char* question, char* string, int length) {
		printf(question);
		const char BACKSPACE = 8;
		int found = 0;
		const char RETURN = 13;
		unsigned char ch = 0;
		DWORD con_mode;
		DWORD dwRead;
		int i = 0;
		HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
		int puntini = 1;
		GetConsoleMode(hIn, &con_mode);
		SetConsoleMode(hIn, con_mode & ~(ENABLE_ECHO_INPUT | ENABLE_LINE_INPUT));
	loop:while (ReadConsoleA(hIn, &ch, 1, &dwRead, NULL) && ch != RETURN) {
			if ((ch > 57 || ch < 48) && ch!= BACKSPACE){
				//Do nothing
			}
			else {
				if (ch == BACKSPACE)
				{
					if (i == 4) {
						printf("\b \b");
						i--;
					}
					if (i != 0) {
						printf("\b \b");
						string[i - 1] = '\0';
						i--;
					}
				}
				else {
					if (i == 2) {
						string[i] = ':';
						i++;
						puntini = 0;
					}
					if (!puntini) {
						printf(":");
						puntini = 1;
					}
					printf("%c", ch);
					if (i == 5) {
						printf("\b \b");
					}
					else {
						string[i] = ch;
						i++;
					}
				}
			}
		}
		printf("\n");
		if (i < 5)
			string[i] = '\0';
		else
			string[5] = '\0';
		i = 0;
		while (string[i] != '\0') {
			if (string[i] == ':')
				found = 1;
			i++;
		}
		if (!found) {
			i = 0;
			printf("Please insert a valid date (you must type at least 3 number)\n");
			goto loop;
		}
		SetConsoleMode(hIn, con_mode);
		if (strlen(string) <= 1)
			return 0;
		return 1;
}
	int yesOrNo(char* question) {
		printf("%s\n", question);
		printf("Yes (Y) or No (N)?\n");
		char risp[2];
		do {
			getInput(1, risp, false);
			if (risp[0] == 'N' || risp[0] == 'n') {
				return 0;
			}
			if (risp[0] == 'Y' || risp[0] == 'y')
				return 1;
			printf("Please stick to the directions\n");
		} while (true);
	}
	void leggiNumeri(int length, char* string) {
redo:	getInput(length, string, false);
		int c = 0;
		for (c = 0; c < strlen(string); c++) {
			if (string[c] < 48 || string[c]>57) {
				printf("You have entered alphabetic characters\n Error\n");
				goto redo;
			}
		}
	}
	int areYouSure() {
		return yesOrNo("\nAre you sure you want to continue with this operation?\n");
	}
